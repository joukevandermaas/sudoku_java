Syntax:
java SudokuSolver <filename> [-b] [max depth]

Filename is the location of the file containing the sudoku. The file
must have one sudoku per line, with the values from left to right, top
to bottom. Empty cells are denoted by a 0.

The -b switch executes the solver in batch mode, solving all sudokus
in the file and reporting statistics. If this switch is left out,
the solver is executed in gui-mode.

A higher maximum depth will make the solver slower, but it will solve
more sudokus. A lower depth will make it faster, but solve fewer sudokus.
The default value is 4.
